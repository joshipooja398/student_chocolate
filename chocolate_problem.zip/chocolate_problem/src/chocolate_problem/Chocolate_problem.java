/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chocolate_problem;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Chocolate_problem 
{

    public static void main(String[] args) 
    {
        int ch, n, k, dis, t, c,cnt=0,difference_store,repeat;
        int chocolate,student;

        Scanner br = new Scanner(System.in);

            System.out.println("=================================");
            System.out.println("Enter your Test case count[1-10]:");
            System.out.println("=================================");
            t = br.nextInt();
            if(t>0 && t<=10)
             {
            
                int[] chocolates = new int[1000]; //Store chocolates in array
                int[] students = new int[100]; //Store students in array

                for (int i = 0; i < t; i++) 
                {
                    System.out.println("Enter  Total Students("+ (i+1) +") between[1-100]"); //Enter student
                    students[i] = br.nextInt();
                    if (students[i] >= 1 && students[i] <= 100) {
                        System.out.println("Enter Total Chocolates("+ (i+1)+") between[1-1000]"); //Enter Chocolate
                        chocolates[i] = br.nextInt();
                        if (chocolates[i] >= 1 && chocolates[i] <= 1000) {

                            if ((students[i] * (students[i] + 1)) / 2 > chocolates[i]) //Total of chocolates are less then total num of student so we are not distribute all chocolates
                            {
                                
                                System.out.println("=================================");
                                System.out.println("Chocolates are less so we are not distribute all chocolate");
                                System.out.println("REMAINING CHOCOLATE = " + chocolates[i]);
                                System.out.println("=================================");
                            } else 
                            {
                                student=students[i];
                                chocolate=chocolates[i];
                                //System.out.println("Total std"+students[i]);
                               // System.out.println("Total choco"+chocolates[i]);
                                k = (((2 * chocolates[i]) + 4 - (students[i] * (students[i] + 1))) / (2 * students[i]))+1;
                               // System.out.println("Students" + students[i]);
                               
                                //System.out.println("K=" + k);
                                for(i=0;i<student;i++)
                               {
                                   cnt+=k;
                                   k++;
                                   
                               }
                                difference_store=chocolate-cnt;
                                //System.out.println("count =" +cnt);
                                System.out.println("=================================");
                                System.out.println("REMAINING CHOCOLATE = " + difference_store);
                                System.out.println("=================================");
                               
                            }
                        }
                        else
                        {
                            System.out.println("Enter Chocolates between [1-1000]"); // Constrains
                        }

                    }
                    else
                    {
                        System.out.println("Enter student between [1-100]"); // Constrains
                    }

                }

            
        
                }
            else
            {
                System.out.println("Enter  case test between [1-10]"); // Constrains
            }
    
    }
}
